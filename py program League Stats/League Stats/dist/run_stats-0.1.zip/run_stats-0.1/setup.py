from distutils.core import setup

setup(
    name="run_stats",
    version='0.1',
    description='one and done stat reference executable',
    author='Chris "Ellroch" Glanzer',
    py_module=['RiotAPI','RiotConsts','UserInterface','Variables','_other_functions','time','requests','main']
)
